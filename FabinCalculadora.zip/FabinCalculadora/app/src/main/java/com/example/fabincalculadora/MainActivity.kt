package com.example.fabincalculadora

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*
import java.util.Stack

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private var memory = 0.0
    private var temp1 = 0.0
    private var temp2 = 0.0 
    private var operacao = 0 
    private var isDegree = true
    private var isHyperbolic = false
    private var isShiftActive = false 
    private var isFtoEActive = false 

    
    private var currentExpression = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display)

        
        setupButtonListeners()
        updateModeDisplay()
    }

    private fun getInput(): Double {
        val text = display.text.toString()
        return if (text.endsWith(".")) {
            (text + "0").toDoubleOrNull() ?: 0.0
        } else {
            text.toDoubleOrNull() ?: 0.0
        }
    }

    private fun updateDisplay(value: Any) {
        val textValue = when (value) {
            is Double -> {
                if (value.isNaN() || value.isInfinite()) {
                    "Erro"
                } else {
                    
                    if (value == floor(value) && !value.toString().contains("E", ignoreCase = true)) {
                        value.toLong().toString()
                    } else {
                        value.toString()
                    }
                }
            }
            else -> value.toString()
        }
        display.text = textValue
        currentExpression = textValue 
    }

    private fun appendToDisplay(char: String) {
        if (display.text.toString() == "0" && char != ".") {
            if (char == "(" || char == ")") {
                 display.text = display.text.toString() + char
                 currentExpression += char
            } else {
                display.text = char
                currentExpression = char
            }
        } else if (display.text.toString() == "Erro") {
            display.text = char
            currentExpression = char
        } else {
            display.text = display.text.toString() + char
            currentExpression += char
        }
    }

    private fun performOperation(newOperation: Int) {
        if (operacao != 0 && display.text.toString() != "Erro" && display.text.isNotEmpty()) {
            
            findViewById<Button>(R.id.btnIgual).performClick()
        }
        temp1 = getInput()
        operacao = newOperation
        display.text = "0" 
        currentExpression = "" 
    }

    private fun calculateResult() {
        if (display.text.toString() == "Erro") return
        val currentInputValue = getInput()
        val result = when (operacao) {
            1 -> temp1 + currentInputValue
            2 -> temp1 - currentInputValue
            3 -> temp1 * currentInputValue
            4 -> if (currentInputValue != 0.0) temp1 / currentInputValue else Double.NaN
            5 -> temp1.pow(currentInputValue) 
            6 -> if (currentInputValue != 0.0) temp1 % currentInputValue else Double.NaN 
            else -> currentInputValue 
        }
        updateDisplay(result)
        operacao = 0 
        temp1 = result 
    }

    private fun factorial(n: Double): Double {
        if (n < 0 || n != floor(n)) return Double.NaN 
        if (n == 0.0) return 1.0
        var result = 1.0
        for (i in 1..n.toInt()) {
            result *= i
        }
        return result
    }

    private fun updateModeDisplay() {
        val degRadButton = findViewById<Button>(R.id.btnDeg)
        val hypButton = findViewById<Button>(R.id.btnHyp)
        val feButton = findViewById<Button>(R.id.btnFE)

        degRadButton.text = if (isDegree) "DEG" else "RAD"
        degRadButton.setBackgroundColor(if (isDegree) getColor(R.color.toggleButtonOnColor) else getColor(R.color.toggleButtonOffColor))

        hypButton.text = if (isHyperbolic) "HYP_ON" else "HYP"
        hypButton.setBackgroundColor(if (isHyperbolic) getColor(R.color.toggleButtonOnColor) else getColor(R.color.toggleButtonOffColor))

        feButton.text = if (isFtoEActive) "F-E_ON" else "F-E"
        feButton.setBackgroundColor(if (isFtoEActive) getColor(R.color.toggleButtonOnColor) else getColor(R.color.toggleButtonOffColor))
        
    }

    
    

    private fun setupButtonListeners() {
        
        val numericButtons = mapOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2", R.id.btn3 to "3",
            R.id.btn4 to "4", R.id.btn5 to "5", R.id.btn6 to "6", R.id.btn7 to "7",
            R.id.btn8 to "8", R.id.btn9 to "9"
        )
        numericButtons.forEach { (id, number) ->
            findViewById<Button>(id).setOnClickListener {
                appendToDisplay(number)
            }
        }

        
        findViewById<Button>(R.id.btnPonto).setOnClickListener {
            if (!display.text.contains(".") && display.text.toString() != "Erro") {
                appendToDisplay(".")
            }
        }

        
        findViewById<Button>(R.id.btnMais).setOnClickListener { performOperation(1) }
        findViewById<Button>(R.id.btnMenos).setOnClickListener { performOperation(2) }
        findViewById<Button>(R.id.btnMultiplicar).setOnClickListener { performOperation(3) }
        findViewById<Button>(R.id.btnDividir).setOnClickListener { performOperation(4) }
        findViewById<Button>(R.id.btnIgual).setOnClickListener { calculateResult() }

        
        findViewById<Button>(R.id.btnCE).setOnClickListener { 
            display.text = "0"
            currentExpression = ""
        }
        findViewById<Button>(R.id.btnC).setOnClickListener { 
            display.text = "0"
            temp1 = 0.0
            temp2 = 0.0
            operacao = 0
            currentExpression = ""
            
            
        }
        findViewById<Button>(R.id.btnBackspace).setOnClickListener {
            val currentText = display.text.toString()
            if (currentText.isNotEmpty() && currentText != "0" && currentText != "Erro") {
                display.text = currentText.dropLast(1)
                currentExpression = currentExpression.dropLast(1)
                if (display.text.isEmpty()) {
                    display.text = "0"
                    currentExpression = ""
                }
            } else if (currentText == "0" || currentText == "Erro"){
                
                display.text = "0"
                currentExpression = ""
            }
        }

        
        findViewById<Button>(R.id.btnMR).setOnClickListener { updateDisplay(memory) } 
        findViewById<Button>(R.id.btnMC).setOnClickListener { memory = 0.0 } 
        findViewById<Button>(R.id.btnMPlus).setOnClickListener { memory += getInput(); display.text = "0"; currentExpression = "" } 
        findViewById<Button>(R.id.btnMMinus).setOnClickListener { memory -= getInput(); display.text = "0"; currentExpression = "" } 
        findViewById<Button>(R.id.btnMS).setOnClickListener { memory = getInput(); display.text = "0"; currentExpression = "" } 

        
        findViewById<Button>(R.id.btnSin).setOnClickListener {
            var angle = getInput()
            if (isDegree) angle = Math.toRadians(angle)
            val result = if (isHyperbolic) sinh(angle) else sin(angle)
            updateDisplay(result)
        }
        findViewById<Button>(R.id.btnCos).setOnClickListener {
            var angle = getInput()
            if (isDegree) angle = Math.toRadians(angle)
            val result = if (isHyperbolic) cosh(angle) else cos(angle)
            updateDisplay(result)
        }
        findViewById<Button>(R.id.btnTan).setOnClickListener {
            var angle = getInput()
            if (isDegree) angle = Math.toRadians(angle)
            val result = if (isHyperbolic) tanh(angle) else tan(angle)
            updateDisplay(result)
        }
        findViewById<Button>(R.id.btnLog).setOnClickListener { 
            val input = getInput()
            updateDisplay(if (input > 0) log10(input) else Double.NaN)
        }
        
        
        
        
        
        

        findViewById<Button>(R.id.btnExp).setOnClickListener { 
            updateDisplay(exp(getInput()))
        }

        findViewById<Button>(R.id.btnFatorial).setOnClickListener {
            updateDisplay(factorial(getInput()))
        }
        findViewById<Button>(R.id.btnPi).setOnClickListener { updateDisplay(PI) }
        

        findViewById<Button>(R.id.btnSquare).setOnClickListener { 
            updateDisplay(getInput().pow(2))
        }
        findViewById<Button>(R.id.btnPower).setOnClickListener { 
            performOperation(5) 
        }
        findViewById<Button>(R.id.btnSqrt).setOnClickListener { 
            val input = getInput()
            updateDisplay(if (input >= 0) sqrt(input) else Double.NaN)
        }
        findViewById<Button>(R.id.btn10PowerX).setOnClickListener { 
            updateDisplay(10.0.pow(getInput()))
        }
        findViewById<Button>(R.id.btnMod).setOnClickListener {
            performOperation(6) 
        }
        findViewById<Button>(R.id.btnToggleSign).setOnClickListener { 
            val currentValue = getInput()
            if (currentValue != 0.0) { 
                updateDisplay(currentValue * -1)
            }
        }

        
        findViewById<Button>(R.id.btnDeg).setOnClickListener { 
            isDegree = !isDegree
            updateModeDisplay()
            val modo = if (isDegree) "Modo: Graus" else "Modo: Radianos"
            Toast.makeText(this, modo, Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnHyp).setOnClickListener {
            isHyperbolic = !isHyperbolic
            updateModeDisplay()
            val modo = if (isHyperbolic) "Hiperbólico Ativado" else "Hiperbólico Desativado"
            Toast.makeText(this, modo, Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnFE).setOnClickListener {
            isFtoEActive = !isFtoEActive
            updateModeDisplay()
            
            Toast.makeText(this, if (isFtoEActive) "Notação F-E Ativada" else "Notação F-E Desativada", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnShift).setOnClickListener {
            isShiftActive = !isShiftActive
            
            
            Toast.makeText(this, if (isShiftActive) "Shift Ativado" else "Shift Desativado", Toast.LENGTH_SHORT).show()
            
        }

        
        
        findViewById<Button>(R.id.btnParenthesesOpen).setOnClickListener {
            appendToDisplay("(")
        }
        findViewById<Button>(R.id.btnParenthesesClose).setOnClickListener {
            appendToDisplay(")")
        }

        
        
    }
}

